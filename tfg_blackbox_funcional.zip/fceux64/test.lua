emu.poweron()
movie.play("C:\\Users\\icalc\\Documents\\TFG\\tfg_blackbox\\temp_movies\\movie0.fm2")
--nombre_archivo="..\\temp_movies\\movie0.fm2"
while true do
    emu.frameadvance()
end